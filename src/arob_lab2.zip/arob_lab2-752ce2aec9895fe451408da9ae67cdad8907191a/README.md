# arob_lab2
Laboratory class 2: Low level control of a mobile robot in ROS
