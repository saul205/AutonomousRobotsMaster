# arob_lab2
Laboratory class 2: Low level control of a mobile robot in ROS

There were no indications of the specific files to send(or I did not find those indications) so we're sending the complete package that results after the lab2 session.

To execute the simulation and follow the path defined on Targets.txt, just use the launchfile "start.launch" as it executes the lowcontrol and followTargets nodes.

roslaunch <path to "start.launch"> launch/start.launch
